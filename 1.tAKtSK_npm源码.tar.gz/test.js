const myPackage = require('./index.js');
console.log(myPackage.greet('AKSK'));