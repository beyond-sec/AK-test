

var AccessId=LTAI5tEt2c8By9hQ7p9qBKrQ
var AccessKey=1NvihL8mdfL8piR8iqNTVCQWrXUEOf 
function greet(name) {
  return `Hello, ${name}!`;
}

module.exports = {
  greet
};