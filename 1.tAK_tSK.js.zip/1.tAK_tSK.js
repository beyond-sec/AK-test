var AccessId='LTAI5tEt2c8By9hQ7p9qBKrQ';
var AccessKey='1NvihL4mdfL9piR9iqNTVCQWrXUEOe' 
function greet(name) {
  return `Hello, ${name}!`;
}

module.exports = {
  greet
};
